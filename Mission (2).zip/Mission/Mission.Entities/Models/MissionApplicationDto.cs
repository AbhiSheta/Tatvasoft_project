﻿public class MissionApplicationDto
{
    public string MissionTitle { get; set; }
    public string MissionTheme { get; set; }
    public string UserName { get; set; }
    public DateTime AppliedDate { get; set; }
    public bool Status { get; set; }
}
