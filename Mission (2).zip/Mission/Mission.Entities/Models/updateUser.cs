﻿

using Microsoft.AspNetCore.Http;

namespace Mission.Entities.Models
{
    public class updateUser
    {
        public int Id { get; set; } // Required for identifying which user to update
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string PhoneNumber { get; set; } = string.Empty;
        public string EmailAddress { get; set; } = string.Empty;
        public IFormFile? UserImage { get; set; } // Optional profile image
    }
}
