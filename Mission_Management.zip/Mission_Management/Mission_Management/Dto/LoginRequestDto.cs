﻿namespace Mission_Management.Dto
{
    public class LoginRequestDto
    {
        public string EmailAddress { get; set; }
        public string Password { get; set; }
    }
}
