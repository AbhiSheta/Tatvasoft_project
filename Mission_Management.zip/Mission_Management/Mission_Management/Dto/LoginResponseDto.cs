﻿namespace Mission_Management.Dto
{
    public class LoginResponseDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string UserType { get; set; }

        public string Token { get; set; }   
    }
}
