
using Microsoft.EntityFrameworkCore;

using Missions.DataAccess.Helpers;
using Missions.DataAccess.context;
//using Missions.DataAccess.Repositories;
//using Missions.Services.IServices;
//using Mission_Mangement.Repositories.Repositories;
//using Missions.DataAccess.IRepositories;
//using Missions.Services.Services;
//using Mission.Service.Services;
//using Mission.Services.Services;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<JwtService>();

builder.Services.AddDbContext<MissionsDbContext>(db => db.UseNpgsql(builder.Configuration.GetConnectionString("DefaultConnection")));
//builder.Services.AddScoped<ILoginRepository, LoginRepository>();
//builder.Services.AddScoped<ILoginService, LoginService>();
//builder.Services.AddScoped<IAdminUserService, AdminUserService>();
//builder.Services.AddScoped<IAdminUserRepository, AdminUserRepository>();
//builder.Services.AddScoped<IUserRepository, UserRepository>();
//builder.Services.AddScoped<IUserService, UserService>();
//builder.Services.AddScoped<ICommonService, CommonService>();
//builder.Services.AddScoped<ICommonRepository, CommonRepository>();
//builder.Services.AddScoped<IMissionSkillService, MissionSkillService>();
//builder.Services.AddScoped<IMissionSkillRepository, MissionSkillRepository>();
//builder.Services.AddScoped<IMissionService, MissionService>();
//builder.Services.AddScoped<IMissionRepository, MissionRepository>();
// Register controllers
builder.Services.AddControllers();

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAngularApp", policy =>
    {
        policy.WithOrigins("http://localhost:4200") // match your Angular app origin exactly
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials(); // optional: if using cookies or auth headers
    });
});


var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
app.UseCors("AllowAngularApp");

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
