﻿namespace Missions.DataAccess
{
    public class Class1
    {

    }
}
