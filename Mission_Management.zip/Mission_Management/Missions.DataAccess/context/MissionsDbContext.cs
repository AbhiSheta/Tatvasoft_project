﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Missions.DataAccess.Models;

namespace Missions.DataAccess.context
{
    public class MissionsDbContext :DbContext
    {
        public MissionsDbContext(DbContextOptions<MissionsDbContext> options) : base(options) { 
        
        }
        public DbSet<User> Users { get; set; }
        public DbSet<MissionTheme> MissionThemes { get; set; }
        public DbSet<MissionSkill> MissionSkills { get; set; }
        public DbSet<Country> Country { get; set; }
        public DbSet<City> City { get; set; }
        public DbSet<Missions.DataAccess.Models.Missions> Missions { get; set; }
        public DbSet<MissionApplication> MissionApplications { get; set; }

    }

}
