﻿namespace Missions.Services
{
    public class Class1
    {

    }
}
